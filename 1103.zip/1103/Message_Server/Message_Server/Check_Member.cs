﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//서버 및 쓰레드 사용 추가
using System.Net.Sockets;
using System.Net;
using System.Threading;

namespace Message_Server
{
    public class Check_Member
    {
        //인트를 바이트로 배열변환
        public byte[] IntToByteArray(int intIn)
        {
            byte[] inttobyte = BitConverter.GetBytes(intIn);
            return inttobyte;
        }

        //바이트 를 인트로 배열변환
        public int ByteArrayToInt(byte[] bytes)
        {
            int bytetoint = ((bytes[3] << 24) + (bytes[2] << 16) + (bytes[1] << 8) + (bytes[0]));
            return bytetoint;
        }

        //스트링 바이트로 배열변환
        public byte[] StringToByteArray(string str)
        {
            byte[] strbyte = new byte[1024];     //바이트 배열의 크기를 결정
            strbyte = Encoding.Unicode.GetBytes(str + "$");

            return strbyte;
        }

        //바이트를 스트링으로 배열변환
        public string ByteArrayToString(int bytes, byte[] strbyte)
        {
            string msg = string.Empty;
            msg = Encoding.Unicode.GetString(strbyte, 0, bytes);
            msg = msg.Substring(0, msg.IndexOf("$"));               // 무조건 처음 받을 때는 string으로 받음

            return msg;
        }

        public void Cross_TextBox(Form form, TextBox txtBox, string msg)                           // 크로스 쓰레드 오류 방지용 함수
        {
            if (txtBox.InvokeRequired)
            {
                form.Invoke(new MethodInvoker(delegate ()
                {
                    txtBox.Text += msg;
                }));
            }
            else
            {
                txtBox.Text += msg;
            }
        }

        public void Cross_RichTextBox(Form form, RichTextBox richBox, string msg)                           // 크로스 쓰레드 오류 방지용 함수
        {
            if (richBox.InvokeRequired)
            {
                form.Invoke(new MethodInvoker(delegate ()
                {
                    richBox.Text += msg;
                }));
            }
            else
            {
                richBox.Text += msg;
            }
        }

        public void Cross_Label(Form form, Label lbl, string str)
        {
            if (lbl.InvokeRequired)
            {
                form.Invoke(new MethodInvoker(delegate ()
                {
                    lbl.Text = str;
                }));
            }
            else
            {
                lbl.Text = str;
            }
        }

        public void Cross_Button(Form form, Button btn, string str)
        {
            if (btn.InvokeRequired)
            {
                form.Invoke(new MethodInvoker(delegate ()
                {
                    btn.Text = str;
                }));
            }
            else
            {
                btn.Text = str;
            }
        }
    }
}
