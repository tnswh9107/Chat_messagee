﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//서버 및 쓰레드 사용 추가
using System.Net.Sockets;
using System.Net;
using System.Threading;
using System.IO;
using System.Diagnostics;

namespace Message_Server
{
    public partial class Me_ser : Form
    {
        //서버 소켓 생성
        public TcpListener serverSock = null;
        //클라이언트 소켓 생성
        public TcpClient clientSock = new TcpClient();
        //스트림 생성
        public NetworkStream stream = null;
        //클라이언트 접속자 증가
        static int count = 0;
        public Check_Member check_member = new Check_Member();

        List<NetworkStream> streams = new List<NetworkStream>();

        //서버 IP
        private string ServIP = "192.168.0.38";
        //서버 포트
        private int Port = 1122;

        private Mutex mutx = new Mutex();

        public Me_ser()
        {
            InitializeComponent();
            serverSock = new TcpListener(IPAddress.Parse(ServIP), Port);
            serverSock.Start();

            new Thread(delegate ()
            {
                InitSocket();
            }).Start();
        }

        private void InitSocket()
        {
            RichTextBox_Text(rich_Message, ">>server Started" + Environment.NewLine);
            while(true)
            {
                try
                {
                    clientSock = serverSock.AcceptTcpClient();

                    if (clientSock.Connected == true)
                    {
                        NetworkStream portStream = clientSock.GetStream();
                        streams.Add(portStream);
                        RichTextBox_Text(rich_Message, $"접속했습니다.\n");
                        byte[] int_byte = new byte[1024];
                        streams[count].Read(int_byte, 0, int_byte.Length);
                        int roomnum = check_member.ByteArrayToInt(int_byte);
                        Thread receive_msg = new Thread(() => receive_ser(streams[0], roomnum));
                        receive_msg.IsBackground = true;
                        receive_msg.Start();
                        count++;
                    }
                }
                catch (SocketException se)
                {
                    Trace.WriteLine(string.Format("InitSocket - SocketException : {0}", se.Message));
                    break;
                }
            }
        }

        private void RichTextBox_Text(RichTextBox richBox, string msg)                           // 크로스 쓰레드 오류 방지용 함수
        {
            if (richBox.InvokeRequired)
            {
                this.Invoke(new MethodInvoker(delegate ()
                {
                    richBox.Text += msg;                    
                }));
            }
            else
            {
                richBox.Text += msg;
            }
        }

        private void receive_ser(NetworkStream stream, int room_num)
        {
            while(true)
            {
                int bytes = 0;
                string msg = string.Empty;
                byte[] str_byte = new byte[1024];
                bytes = stream.Read(str_byte, 0, str_byte.Length);
                msg = check_member.ByteArrayToString(bytes, str_byte);
                send_ser(stream, msg, room_num);
            }
        }

        private void send_ser(NetworkStream stream, string message, int room_num)
        {
            message = room_num + "|" + message;
            byte[] str_byte = check_member.StringToByteArray(message);
            for(int i=0; i<count; i++)
            {
                streams[i].Write(str_byte, 0, str_byte.Length);
            }
        }


    }
}
