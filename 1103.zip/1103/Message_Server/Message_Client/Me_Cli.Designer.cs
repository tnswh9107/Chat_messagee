﻿namespace Message_Client
{
    partial class Me_Cli
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.pic_Main = new System.Windows.Forms.PictureBox();
            this.lbl_Title = new System.Windows.Forms.Label();
            this.btn_Pictur = new System.Windows.Forms.Button();
            this.btn_Message = new System.Windows.Forms.Button();
            this.btn_Calendar = new System.Windows.Forms.Button();
            this.btn_Home = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Main)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 4;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.Controls.Add(this.pic_Main, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.lbl_Title, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.btn_Pictur, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.btn_Message, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.btn_Calendar, 3, 5);
            this.tableLayoutPanel1.Controls.Add(this.btn_Home, 0, 5);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 6;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(800, 450);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // pic_Main
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.pic_Main, 2);
            this.pic_Main.Dock = System.Windows.Forms.DockStyle.Right;
            this.pic_Main.Location = new System.Drawing.Point(37, 83);
            this.pic_Main.Name = "pic_Main";
            this.tableLayoutPanel1.SetRowSpan(this.pic_Main, 4);
            this.pic_Main.Size = new System.Drawing.Size(360, 314);
            this.pic_Main.TabIndex = 0;
            this.pic_Main.TabStop = false;
            // 
            // lbl_Title
            // 
            this.lbl_Title.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_Title.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.lbl_Title, 4);
            this.lbl_Title.Font = new System.Drawing.Font("궁서체", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_Title.Location = new System.Drawing.Point(265, 25);
            this.lbl_Title.MaximumSize = new System.Drawing.Size(270, 30);
            this.lbl_Title.MinimumSize = new System.Drawing.Size(270, 30);
            this.lbl_Title.Name = "lbl_Title";
            this.lbl_Title.Size = new System.Drawing.Size(270, 30);
            this.lbl_Title.TabIndex = 1;
            this.lbl_Title.Text = "우리들의 모임 IOT Band";
            // 
            // btn_Pictur
            // 
            this.btn_Pictur.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_Pictur.Location = new System.Drawing.Point(203, 403);
            this.btn_Pictur.Name = "btn_Pictur";
            this.btn_Pictur.Size = new System.Drawing.Size(194, 44);
            this.btn_Pictur.TabIndex = 3;
            this.btn_Pictur.Text = "앨범";
            this.btn_Pictur.UseVisualStyleBackColor = true;
            this.btn_Pictur.Click += new System.EventHandler(this.btn_Pictur_Click);
            // 
            // btn_Message
            // 
            this.btn_Message.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_Message.Location = new System.Drawing.Point(403, 403);
            this.btn_Message.Name = "btn_Message";
            this.btn_Message.Size = new System.Drawing.Size(194, 44);
            this.btn_Message.TabIndex = 3;
            this.btn_Message.Text = "메시지";
            this.btn_Message.UseVisualStyleBackColor = true;
            this.btn_Message.Click += new System.EventHandler(this.btn_Message_Click);
            // 
            // btn_Calendar
            // 
            this.btn_Calendar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_Calendar.Location = new System.Drawing.Point(603, 403);
            this.btn_Calendar.Name = "btn_Calendar";
            this.btn_Calendar.Size = new System.Drawing.Size(194, 44);
            this.btn_Calendar.TabIndex = 3;
            this.btn_Calendar.Text = "달력";
            this.btn_Calendar.UseVisualStyleBackColor = true;
            this.btn_Calendar.Click += new System.EventHandler(this.btn_Calendar_Click);
            // 
            // btn_Home
            // 
            this.btn_Home.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_Home.Location = new System.Drawing.Point(3, 403);
            this.btn_Home.Name = "btn_Home";
            this.btn_Home.Size = new System.Drawing.Size(194, 44);
            this.btn_Home.TabIndex = 4;
            this.btn_Home.Text = "홈";
            this.btn_Home.UseVisualStyleBackColor = true;
        
            // 
            // Me_Cli
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "Me_Cli";
            this.Text = "Client";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Main)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.PictureBox pic_Main;
        private System.Windows.Forms.Label lbl_Title;
        private System.Windows.Forms.Button btn_Pictur;
        private System.Windows.Forms.Button btn_Message;
        private System.Windows.Forms.Button btn_Calendar;
        private System.Windows.Forms.Button btn_Home;
    }
}

