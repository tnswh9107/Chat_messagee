﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace Message_Client
{
    public partial class cl_MsgRoom : Form
    {
        Me_Cli cl_msgroom;
        

        public cl_MsgRoom()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            cl_msgroom = (Me_Cli)this.Owner;
            cl_msgroom.cl_room = 1;
            byte[] int_byte = cl_msgroom.check_member.IntToByteArray(cl_msgroom.cl_room);
            cl_msgroom.stream.Write(int_byte, 0, int_byte.Length);

            Form cl_message = new cl_Message();
            cl_message.Owner = cl_msgroom;
            cl_message.Show();
        }

        private void btn_num2_Click(object sender, EventArgs e)
        {
            cl_msgroom = (Me_Cli)this.Owner;
            cl_msgroom.cl_room = 2;
            byte[] int_byte = cl_msgroom.check_member.IntToByteArray(cl_msgroom.cl_room);
            cl_msgroom.stream.Write(int_byte, 0, int_byte.Length);

            Form cl_message = new cl_Message();
            cl_message.Owner = cl_msgroom;
            cl_message.Show();
        }

        private void btn_num3_Click(object sender, EventArgs e)
        {
            cl_msgroom = (Me_Cli)this.Owner;
            cl_msgroom.cl_room = 3;
            byte[] int_byte = cl_msgroom.check_member.IntToByteArray(cl_msgroom.cl_room);
            cl_msgroom.stream.Write(int_byte, 0, int_byte.Length);

            Form cl_message = new cl_Message();
            cl_message.Owner = cl_msgroom;
            cl_message.Show();
        }

        private void btn_num4_Click(object sender, EventArgs e)
        {
            cl_msgroom = (Me_Cli)this.Owner;
            cl_msgroom.cl_room = 4;
            byte[] int_byte = cl_msgroom.check_member.IntToByteArray(cl_msgroom.cl_room);
            cl_msgroom.stream.Write(int_byte, 0, int_byte.Length);

            Form cl_message = new cl_Message();
            cl_message.Owner = cl_msgroom;
            cl_message.Show();
        }
    }
}
