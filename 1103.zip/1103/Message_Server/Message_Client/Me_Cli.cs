﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//서버 및 쓰레드 사용 추가
using System.Net.Sockets;
using System.Net;
using System.Threading;

namespace Message_Client
{
    public partial class Me_Cli : Form
    {
        // Client 소켓 생성
        public TcpClient clientSock = new TcpClient();
        public NetworkStream stream = null;        

        public TcpClient album_1 = new TcpClient();
        public NetworkStream stream_al = null;
        public TcpClient calendar_1 = new TcpClient();
        public NetworkStream stream_ca = null;
        public TcpClient msgroom_1 = new TcpClient();
        public NetworkStream stream_ms = null;

        //방 번호 체크
        public int[] room_num = new int[4]; //방이 4개
        public int[] room_check = new int[4];   //0 = 빈방 , 1 = 접속
        public int cl_room = 0; //어느방에 접속했는지 확인

        // 인트 스트링 바이트 변환
        public Check_Member check_member = new Check_Member();

        private string ServIP = "192.168.0.38";
        private int Port = 1122;
      
        public Me_Cli()
        {
            CenterToScreen();
            InitializeComponent();

            //쓰레드 InitSocket 생성후 시작
            new Thread(delegate ()
            {
                InitSocket();
            }).Start();
        }

        //쓰레드 확인
        private void InitSocket()
        {
            try
            {
                clientSock.Connect(IPAddress.Parse(ServIP), Port);
                stream = clientSock.GetStream();
            }
            catch (SocketException se)
            {
                MessageBox.Show(se.Message, "Error");
            }
        }

        private void btn_Pictur_Click(object sender, EventArgs e)
        {            
            CenterToScreen();
            Form cl_album = new cl_Album();
            cl_album.Owner = this;
            cl_album.Show();
        }

        private void btn_Message_Click(object sender, EventArgs e)
        {
            CenterToScreen();
            Form cl_msgRoom = new cl_MsgRoom();
            cl_msgRoom.Owner = this;
            cl_msgRoom.Show();            
        }

        private void btn_Calendar_Click(object sender, EventArgs e)
        {
            CenterToScreen();
            Form cl_calendar = new cl_Calendar();
            cl_calendar.Show();
        }        
    }
}
