﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO;
using System.Threading;
using System.Net;
using System.Net.Sockets;

namespace Message_Client
{
    public partial class cl_Message : Form
    {

        Me_Cli me_cli;
            

        string message = string.Empty;

        public cl_Message()
        {
            
            InitializeComponent();
            this.ActiveControl = Rich_Txt;  //포커스
        }

        
        private void btn_Send_Click(object sender, EventArgs e)
        {
            this.ActiveControl = Rich_Txt;  
            me_cli = (Me_Cli)this.Owner;
            byte[] str_byte = me_cli.check_member.StringToByteArray(Rich_Txt.Text);
            me_cli.stream.Write(str_byte, 0, str_byte.Length);
            me_cli.stream.Flush();  //스트림 값 초기화
            Rich_Txt.Clear();

        }

        private void receive_msg()
        {
            while(true)
            {
                int bytes = 0;
                string msg = string.Empty;
                byte[] str_byte = new byte[1024];
                bytes = me_cli.stream.Read(str_byte, 0, str_byte.Length);
                msg = me_cli.check_member.ByteArrayToString(bytes, str_byte);
                string[] check_name = msg.Split('|');
                if(check_name[0] == $"{me_cli.cl_room}")
                {
                    me_cli.check_member.Cross_RichTextBox(this, rich_Show, check_name[1]);
                }
            }
        }
    }
}
