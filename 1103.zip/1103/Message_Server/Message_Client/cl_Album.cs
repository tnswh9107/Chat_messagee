﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Net;
using System.Net.Sockets;

namespace Message_Client
{
    public partial class cl_Album : Form
    {
        Me_Cli me_cl;

        public cl_Album()
        {
            me_cl = (Me_Cli)this.Owner;
            InitializeComponent();            
        }
    }
}
