﻿namespace Message_Client
{
    partial class cl_Message
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rich_Show = new System.Windows.Forms.RichTextBox();
            this.Rich_Txt = new System.Windows.Forms.TextBox();
            this.lab_Txt = new System.Windows.Forms.Label();
            this.btn_Send = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rich_Show
            // 
            this.rich_Show.Location = new System.Drawing.Point(12, 12);
            this.rich_Show.Name = "rich_Show";
            this.rich_Show.Size = new System.Drawing.Size(628, 248);
            this.rich_Show.TabIndex = 0;
            this.rich_Show.Text = "";
            // 
            // Rich_Txt
            // 
            this.Rich_Txt.Location = new System.Drawing.Point(123, 292);
            this.Rich_Txt.Name = "Rich_Txt";
            this.Rich_Txt.Size = new System.Drawing.Size(389, 21);
            this.Rich_Txt.TabIndex = 1;
            // 
            // lab_Txt
            // 
            this.lab_Txt.AutoSize = true;
            this.lab_Txt.Font = new System.Drawing.Font("바탕", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lab_Txt.Location = new System.Drawing.Point(13, 294);
            this.lab_Txt.Name = "lab_Txt";
            this.lab_Txt.Size = new System.Drawing.Size(110, 19);
            this.lab_Txt.TabIndex = 2;
            this.lab_Txt.Text = "보낼 텍스트";
            // 
            // btn_Send
            // 
            this.btn_Send.Location = new System.Drawing.Point(531, 292);
            this.btn_Send.Name = "btn_Send";
            this.btn_Send.Size = new System.Drawing.Size(109, 23);
            this.btn_Send.TabIndex = 3;
            this.btn_Send.Text = "보내기";
            this.btn_Send.UseVisualStyleBackColor = true;
            this.btn_Send.Click += new System.EventHandler(this.btn_Send_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(531, 360);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "나가기";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // cl_Message
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(655, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btn_Send);
            this.Controls.Add(this.lab_Txt);
            this.Controls.Add(this.Rich_Txt);
            this.Controls.Add(this.rich_Show);
            this.Name = "cl_Message";
            this.Text = "cl_Message";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox rich_Show;
        private System.Windows.Forms.TextBox Rich_Txt;
        private System.Windows.Forms.Label lab_Txt;
        private System.Windows.Forms.Button btn_Send;
        private System.Windows.Forms.Button button1;
    }
}